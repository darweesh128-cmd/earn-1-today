# Suggested pricing (USD) — freelancers selling to intl clients

| Offer | Price | Notes |
|-------|-------|-------|
| Caption pack only (this kit resale / use) | $5–15 | Instant digital |
| Captions + custom invoice branding | $25–40 | 24h |
| Full WhatsApp sales script for 1 offer | $49–99 | Includes 1 revision |
| Monthly WA content retainer | $150–400 | 12–20 messages |

Pay international buyers via **PayPal friends/goods** or PayPal.me — avoid forcing local bank rails.
