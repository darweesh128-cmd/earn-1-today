# Quick start — Client Close Kit (AR/EN)

1. Open `whatsapp-captions-ar-en.csv` in Google Sheets / Excel.
2. Replace bracket placeholders like `[رابط]` / `[link]` with your real links.
3. Customize `invoice-print.html` → Print → Save as PDF for each client.
4. Send `quote-template.html` (or paste into WhatsApp) before you start work.
5. Use `followup-7day.md` only after a real quote — never cold-spam.

**License for buyers:** personal + commercial use for your own freelancing. Do not claim authorship of the pack as exclusive IP; you may rebrand messages for clients.
