# 7-day soft follow-up (after quote sent)

Copy/paste. Keep tone helpful, not pushy.

| Day | Channel | Message |
|-----|---------|---------|
| 0 | WhatsApp | Quote sent — happy to adjust scope if needed. |
| 1 | WhatsApp | Quick check: any questions on the deliverables? |
| 3 | WhatsApp | Still holding the slot until [date]. Want a smaller starter package? |
| 5 | Email/WA | Sharing a 1-line sample of how I'd open the first client message. |
| 7 | WhatsApp | Closing the quote loop — reply later anytime; no hard feelings. |

## Rules
- Max 1 nudge per day.
- Stop immediately if they say no / not now.
- Never invent scarcity you cannot honor.
